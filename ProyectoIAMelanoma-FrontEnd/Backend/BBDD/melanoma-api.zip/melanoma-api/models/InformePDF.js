const mongoose = require('mongoose');

const InformePDFSchema = new mongoose.Schema({
    id: { type: String, required: true, unique: true },
    usuarioId: { type: String, required: true },
    contenido: { type: String, required: true },
    fechaGeneracion: { type: Date, default: Date.now }
});

module.exports = mongoose.model('InformePDF', InformePDFSchema);
