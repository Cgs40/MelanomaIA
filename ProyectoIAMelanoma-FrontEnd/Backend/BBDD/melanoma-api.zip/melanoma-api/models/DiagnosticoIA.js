const mongoose = require('mongoose');

const DiagnosticoIASchema = new mongoose.Schema({
    imagenId: { type: mongoose.Schema.Types.ObjectId, ref: 'Imagen', required: true },
    resultado: { type: String, required: true },
});

module.exports = mongoose.model('DiagnosticoIA', DiagnosticoIASchema);
