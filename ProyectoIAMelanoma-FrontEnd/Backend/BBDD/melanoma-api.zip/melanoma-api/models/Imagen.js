const mongoose = require('mongoose');

const ImagenSchema = new mongoose.Schema({
    usuarioId: { type: mongoose.Schema.Types.ObjectId, ref: 'Usuario', required: true },
    ruta: { type: String, required: true },
    fechaSubida: { type: Date, default: Date.now },
    codigoCategoria: { type: String, required: true },
});

module.exports = mongoose.model('Imagen', ImagenSchema);
