const mongoose = require('mongoose');

const UsuarioSchema = new mongoose.Schema({
    id: { type: String, required: true, unique: true },
    nombre: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    contraseña: { type: String, required: true },
    rol: { type: String },
});

module.exports = mongoose.model('Usuario', UsuarioSchema);
