const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const Imagen = require('../models/Imagen');
const DiagnosticoIA = require('../models/DiagnosticoIA');


const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, './uploads');
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname));
    },
});

const upload = multer({ storage: storage });


router.post('/subir', upload.single('imagen'), async (req, res) => {
    try {
        const nuevaImagen = new Imagen({
            usuarioId: req.body.usuarioId,  
            ruta: req.file.path,
            codigoCategoria: req.body.codigoCategoria,
        });

        await nuevaImagen.save();
        res.status(201).json({ message: 'Imagen subida correctamente', imagen: nuevaImagen });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Error al subir la imagen' });
    }
});


router.post('/diagnostico', async (req, res) => {
    try {
        const { imagenId, resultado } = req.body;
        const nuevoDiagnostico = new DiagnosticoIA({
            imagenId,
            resultado,
        });

        await nuevoDiagnostico.save();
        res.status(201).json({ message: 'Diagnóstico guardado correctamente', diagnostico: nuevoDiagnostico });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Error al guardar diagnóstico' });
    }
});

module.exports = router;
